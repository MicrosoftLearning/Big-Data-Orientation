var config = {}

config.endpoint = "<cosmosdb>.graphs.azure.com";
config.primaryKey = "abcdefg1234567==";
config.database = "GraphDB"
config.collection = "EmployeeGraph"

module.exports = config;